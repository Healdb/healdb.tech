<?php
echo '<html><p>Hello ' . $_GET["name"] . '!<p>';
?>
