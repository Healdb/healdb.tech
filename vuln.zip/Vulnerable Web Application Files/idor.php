<?php
if(isset($_GET["id"])){
	if($_GET["id"] == "1"){
		echo("Name: John Smith");
	}
	if($_GET["id"] == "2"){
		echo("Name: Janice Tolland");
	}
	if($_GET["id"] == "3"){
		echo("Name: Peter Tall");
	}
}
else{
	header("Location: http://localhost/idor.php?id=1");
}
?>
