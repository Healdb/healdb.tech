<?php
$homepage = file_get_contents($_GET["url"]);
echo $homepage;
?>
